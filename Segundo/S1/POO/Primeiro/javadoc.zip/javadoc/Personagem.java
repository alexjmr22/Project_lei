/**
 * A classe Personagem representa um personagem genérico em um jogo de RPG.
 * Cada personagem possui um nome, nível de experiência e atributos como força,
 * agilidade e inteligência.
 */
public class Personagem {
    protected String nome;
    protected int nivelExperiencia;
    protected int forca;
    protected int agilidade;
    protected int inteligencia;

    /**
     * Construtor da classe Personagem. Inicializa o nome e o nível de experiência
     * do personagem.
     *
     * @param nome O nome do personagem.
     */

    public Personagem(String nome) {
        this.nome = nome;
        this.nivelExperiencia = (int) (Math.random() * 25) + 1;
    }

    /**
     * Define o nível de experiência do personagem.
     *
     * @param nivelExperiencia O novo nível de experiência.
     */

    public void setNivelExperiencia(int nivelExperiencia) {
        this.nivelExperiencia = nivelExperiencia;
    }

    /**
     * Obtém o nome do personagem.
     *
     * @return O nome do personagem.
     */

    public String getNome() {
        return nome;
    }

    /**
     * Obtém o nível de experiência do personagem.
     *
     * @return O nível de experiência do personagem.
     */

    public int getNivelExperiencia() {
        return nivelExperiencia;
    }

    /**
     * Obtém a força do personagem.
     *
     * @return A força do personagem.
     */

    public int getForca() {
        return forca;
    }

    /**
     * Define a força do personagem.
     *
     * @param forca A nova força do personagem.
     */

    public void setForca(int forca) {
        this.forca = forca;
    }

     /**
     * Obtém a agilidade do personagem.
     *
     * @return A agilidade do personagem.
     */

    public int getAgilidade() {
        return agilidade;
    }

    /**
     * Define a agilidade do personagem.
     *
     * @param agilidade A nova agilidade do personagem.
     */

    public void setAgilidade(int agilidade) {
        this.agilidade = agilidade;
    }

     /**
     * Obtém a inteligência do personagem.
     *
     * @return A inteligência do personagem.
     */

    public int getInteligencia() {
        return inteligencia;
    }

    /**
     * Define a inteligência do personagem.
     *
     * @param inteligencia A nova inteligência do personagem.
     */

    public void setInteligencia(int inteligencia) {
        this.inteligencia = inteligencia;
    }

    /**
     * Método abstrato que representa a ação de subir de nível do personagem.
     * Cada tipo específico de personagem implementará sua própria lógica de
     * subida de nível.
     */

    public void subirNivel() {
        // Implementação específica em cada classe derivada.
    }
    
}
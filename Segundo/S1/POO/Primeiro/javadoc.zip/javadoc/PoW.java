import java.util.ArrayList;
/**
 * A classe PoW representa um jogo de RPG onde personagens com diferentes
 * características lutam em parcerias.
 */
public class PoW {
    
    private ArrayList<Personagem> personagens;

    /**
     * Construtor da classe PoW. Inicializa a lista de personagens e chama o
     * método para inicializar os personagens.
     */

    public PoW() {
        this.personagens = new ArrayList<>();
        inicializarPersonagens();
    }

    /**
     * Inicializa a lista de personagens com guerreiros, magos e mercenários.
     */

    private void inicializarPersonagens() {
        for (int i = 0; i < 5; i++) {
            personagens.add(new Guerreiro("Guerreiro" + (i + 1)));
            personagens.add(new Mago("Mago" + (i + 1)));
            personagens.add(new Mercenario("Mercenario" + (i + 1)));
        }
    }

    /**
     * Imprime o nome e nível de experiência de todas as personagens.
     */

    public void imprimirPersonagens() {
        for (Personagem personagem : personagens) {
            System.out.println("Nome: " + personagem.getNome() + ", Nível de Experiência: " + personagem.getNivelExperiencia());
        }
    }

    /**
     * Imprime o nome e nível de experiência das personagens com nível superior a 10.
     */

    public void imprimirPersonagensNivelSuperiorA10() {
        for (Personagem personagem : personagens) {
            if (personagem.getNivelExperiencia() > 10) {
                System.out.println("Nome: " + personagem.getNome() + ", Nível de Experiência: " + personagem.getNivelExperiencia());
            }
        }
    }

     /**
     * Imprime personagens específicos com suas características.
     */

    public void imprimirPersonagensEspecificos() {
        for (Personagem personagem : personagens) {
            if (personagem instanceof Guerreiro && ((Guerreiro) personagem).isTemArmadura()) {
                System.out.println("Guerreiro com Armadura - Nome: " + personagem.getNome() + ", Nível de Experiência: " + personagem.getNivelExperiencia());
            } else if (personagem instanceof Mago && contemSementeDeAbobora((Mago) personagem)) {
                System.out.println("Mago com Sementes de Abóbora - Nome: " + personagem.getNome() + ", Nível de Experiência: " + personagem.getNivelExperiencia());
            } else if (personagem instanceof Mercenario && "arco".equals(((Mercenario) personagem).getArmaLongoAlcance())) {
                System.out.println("Mercenário com Arco - Nome: " + personagem.getNome() + ", Nível de Experiência: " + personagem.getNivelExperiencia());
            }
        }
    }

    /**
     * Verifica se um mago tem sementes de abóbora na mochila.
     *
     * @param mago O mago a ser verificado.
     * @return true se o mago tiver sementes de abóbora, false caso contrário.
     */

    private boolean contemSementeDeAbobora(Mago mago) {
        for (String item : mago.getMochila()) {
            if ("sementes".equalsIgnoreCase(item)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Mostra estatísticas das personagens antes e depois de subir de nível.
     */

    public void mostrarEstatisticasAntesDepoisSubirNivel() {
    System.out.println("Estatísticas antes de subir de nível:");
    imprimirCabecalhoTabela();

    for (Personagem personagem : personagens) {
        imprimirLinhaTabela(personagem);
    }

    System.out.println("\nSubindo de nível...");

    for (Personagem personagem : personagens) {
        personagem.subirNivel(); // Chamando o método subirNivel específico de cada classe
    }

    System.out.println("\nEstatísticas depois de subir de nível:");
    imprimirCabecalhoTabela();

    for (Personagem personagem : personagens) {
        imprimirLinhaTabela(personagem);
    }
}

/**
     * Imprime o cabeçalho da tabela de estatísticas.
     */

private void imprimirCabecalhoTabela() {
    System.out.printf("%-15s %-20s %-10s %-10s %-15s%n", "Nome", "Nível Exp", "Força", "Agilidade", "Inteligência");
    System.out.println("-------------------------------------------------------------------------");
}

/**
     * Imprime uma linha da tabela de estatísticas para uma personagem.
     *
     * @param personagem A personagem a ser impressa.
     */

private void imprimirLinhaTabela(Personagem personagem) {
    System.out.printf("%-15s %-20s %-10s %-10s %-15s%n",
            personagem.getNome(),
            personagem.getNivelExperiencia(),
            personagem.getForca(),
            personagem.getAgilidade(),
            personagem.getInteligencia());
}

    /**
     * O método principal que cria uma instância de PoW e realiza algumas ações do jogo.
     *
     * @param args Os argumentos da linha de comando (não são utilizados neste caso).
     */
    public static void main(String[] args) {
        PoW jogo = new PoW();

        System.out.println("Imprimindo todas as personagens:");
        jogo.imprimirPersonagens();

        System.out.println("\nImprimindo personagens com nível superior a 10:");
        jogo.imprimirPersonagensNivelSuperiorA10();

        System.out.println("\nImprimindo personagens específicos:");
        jogo.imprimirPersonagensEspecificos();

        System.out.println("\nMostrando estatísticas antes e depois de subir de nível:");
        jogo.mostrarEstatisticasAntesDepoisSubirNivel();
    }

}
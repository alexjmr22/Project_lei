/**
 * A classe Guerreiro representa um tipo de personagem no jogo PoW com características específicas.
 * Guerreiros podem ou não ter armaduras e possuem uma arma de curto alcance.
 */
class Guerreiro extends Personagem {
    private boolean temArmadura;
    private String armaCurtoAlcance;

    /**
     * Construtor da classe Guerreiro. Inicializa o nome, atributos e características específicas do guerreiro.
     *
     * @param nome O nome do guerreiro.
     */

    public Guerreiro(String nome) {
        super(nome);
        this.forca = 10;
        this.agilidade = 5;
        this.inteligencia = 3;
        this.temArmadura = Math.random() < 0.5; // 50% de chance de ter armadura
        this.armaCurtoAlcance = gerarArmaCurtoAlcance();
    }

    /**
     * Verifica se o guerreiro possui armadura.
     *
     * @return true se o guerreiro tem armadura, false caso contrário.
     */

    public boolean isTemArmadura() {
        return temArmadura;
    }

    /**
     * Obtém a arma de curto alcance do guerreiro.
     *
     * @return A arma de curto alcance do guerreiro.
     */

    public String getArmaCurtoAlcance() {
        return armaCurtoAlcance;
    }

    /**
     * Gera uma arma de curto alcance aleatória para o guerreiro.
     *
     * @return A arma de curto alcance gerada.
     */

    private String gerarArmaCurtoAlcance() {
        String[] armas = {"facas", "machados", "espadas"};
        return armas[(int) (Math.random() * armas.length)];
    }

    /**
     * Implementação da subida de nível para guerreiros. Aumenta os atributos
     * de força, agilidade e inteligência de acordo com regras específicas.
     */

    public void subirNivel() {
        setNivelExperiencia(getNivelExperiencia() + 1);
        setForca((int) (getForca() * 1.2));
        setAgilidade((int) (getAgilidade() * 1.1));
        setInteligencia((int) (getInteligencia() * 1.05));
    }
}
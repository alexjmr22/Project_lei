/**
 * A classe Mercenario representa um tipo de personagem no jogo PoW com características específicas.
 * Mercenários têm uma arma de longo alcance e um número de munições.
 */
class Mercenario extends Personagem {
    private String armaLongoAlcance;
    private int numeroMunicoes;

    /**
     * Construtor da classe Mercenario. Inicializa o nome, atributos e características
     * específicas do mercenário, como a arma de longo alcance e número de munições.
     *
     * @param nome O nome do mercenário.
     */

    public Mercenario(String nome) {
        super(nome);
        this.forca = 4;
        this.agilidade = 10;
        this.inteligencia = 4;
        this.armaLongoAlcance = gerarArmaLongoAlcance();
        this.numeroMunicoes = (int) (Math.random() * 50) + 1;
    }

    /**
     * Obtém a arma de longo alcance do mercenário.
     *
     * @return A arma de longo alcance do mercenário.
     */

    public String getArmaLongoAlcance() {
        return armaLongoAlcance;
    }
    /**
     * Obtém o número de munições do mercenário.
     *
     * @return O número de munições do mercenário.
     */

    public int getNumeroMunicoes() {
        return numeroMunicoes;
    }
    /**
     * Gera uma arma de longo alcance aleatória para o mercenário.
     *
     * @return A arma de longo alcance gerada.
     */
    private String gerarArmaLongoAlcance() {
        String[] armas = {"pedras", "arcos", "pistolas"};
        return armas[(int) (Math.random() * armas.length)];
    }

    /**
     * Implementação da subida de nível para mercenários. Aumenta os atributos
     * de força, agilidade e inteligência de acordo com regras específicas.
     */
    
    public void subirNivel() {
        setNivelExperiencia(getNivelExperiencia() + 1);
        setForca((int) (getForca() * 1.08));
        setAgilidade((int) (getAgilidade() * 1.2));
        setInteligencia((int) (getInteligencia() * 1.08));
    }
}
/**
 * A classe Mago representa um tipo de personagem no jogo PoW com características específicas.
 * Magos têm uma mochila contendo sementes e folhas.
 */

class Mago extends Personagem {
    private String[] mochila;

    /**
     * Construtor da classe Mago. Inicializa o nome, atributos e a mochila do mago.
     *
     * @param nome O nome do mago.
     */

    public Mago(String nome) {
        super(nome);
        this.forca = 2;
        this.agilidade = 4;
        this.inteligencia = 9;
        this.mochila = new String[]{"sementes", "folhas"};
    }

    /**
     * Obtém a mochila do mago.
     *
     * @return A mochila do mago.
     */

    public String[] getMochila() {
        return mochila;
    }

    /**
     * Implementação da subida de nível para magos. Aumenta os atributos
     * de força, agilidade e inteligência de acordo com regras específicas.
     */
    
    public void subirNivel() {
        setNivelExperiencia(getNivelExperiencia() + 1);
        setForca((int) (getForca() * 1.05));
        setAgilidade((int) (getAgilidade() * 1.1));
        setInteligencia((int) (getInteligencia() * 1.2));
    }

}